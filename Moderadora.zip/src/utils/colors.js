module.exports = {
  default: '#5865f2',
  mod: '#ff4343',
  vip: '#ffc100',
  maintenance: '#7900ff',
  lightgreen: '#57F287',
  lightblue: '#0097ff'
}